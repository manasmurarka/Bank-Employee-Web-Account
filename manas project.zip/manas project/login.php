<html>

<head>
 <title>Login Page</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
   body{
    background-color:white;
   }

    #container{
      background-color:white;
   }

    #first{
      font-size:15px;
      padding:0px 0px 0px 10px;
   }

    #second{
      font-size:20px;
      background-color:pink;
   }
  </style>
 </head>

<body>
 <?php
session_start();
  $flag=88;
  include "config.php";
   
   $x=$_POST["check"];

   $b=$_POST["user"];
   $c=$_POST["pwd"];

   $sql1="select * from login where username='".$b."' and password='".$c."' ";
   $result=$conn->query($sql1);
   if($result->num_rows>0)
    { 
      while($row=$result->fetch_assoc())
      { 
        if($row[password]==$c)
          {
            $flag=1;
            $_SESSION["uid"]=$row[userid]; 

            }
        else
          $flag=88;
      }
    }
  
 ?>
 <div id="container">
  <?php
    if($flag==1)
   {
  ?>
   <div id="zero">
     <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home2.php">SBI Bank</a>
    </div>
    <ul class="nav navbar-nav">
      <li  class="active"><a href="home2.php">Home</a></li>
      <li><a href="new_acc.php">New Account</a></li>
      <li><a href="transaction_withdraw.php">Withdraw</a></li>
      <li><a href="transaction_deposit.php">Deposit</a></li>
      <li><a href="transfer.php">Transfer</a></li>
      <li><a href="report.php">Report</a></li>
      
    </ul>
  </div>
</nav>
   <center><iframe src="home3.php" name="inline" height=300px width=800px style="border:none;"></iframe></center>
   </div> 
  <?php
  }
  ?>

<?php
  if($flag==88)
{
?>
 <div id="first">


 <center><h1>Login to the Account</center>
 <br><br>
 </div>

 <div id="second">
 <center>
 <form action="login.php" method="post">
   <pre>
   Username:        <input type="text" name="user"><br>
   Password:        <input type="password" name="pwd"><br>
   <br>
   <input type="submit" class="btn btn-lg btn-primary" value="login" name="check" >
   </pre>
 </form>
 </center>
   
   
 </div>
<?php
}
?>
 </div>
</body>

</html>
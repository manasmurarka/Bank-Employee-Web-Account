<html>

<head>
 <title>Home-SBI</title>
 <link rel="stylesheet" type="text/css" href="home.css"/>
</head>

<body>
 <div id="d1">
 <center>
 <h1>Welcome to SBI Bank.</h1>
 <h4>Please click on Login page to Login.</h4>
 </center> 
 </div>
</body>

</html>
<!DOCTYPE html>
<html>
<body>

 &copy; 2010-  <?php echo date("Y") ?>

</body>
</html>
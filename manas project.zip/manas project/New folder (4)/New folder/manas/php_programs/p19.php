<!DOCTYPE html>
<html>
<body>

<?php
  function sum($x,$y)
  { $z=$x+$y;
    return $z; }
  
  echo "5+10=".sum(5,10)."<br>";
  echo "6+100=".sum(6,100)."<br>";
?>

</body>
</html>
<!DOCTYPE html>
<html>
<body>

<?php
 
  for($x= 1;$x<=5;$x++)
 {
    echo "The Number is: $x"."<br>"; // or echo "The Number is: $x<br>";
    
 }
?>

</body>
</html>
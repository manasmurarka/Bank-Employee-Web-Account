<!DOCTYPE html>
<html>
<body>

<?php
 define("Greeting", "Welcome to w3schools.com!");
 function myTest()
 {
  echo Greeting;
 }
 myTest();
?>

</body>
</html>
<!DOCTYPE html>
<html>
<body>

<?php
  $cars= array("Toyota", "Bmw","Audi");
  echo "I like ".$cars[0].", ".$cars[1].", ".$cars[2].".";
?>

</body>
</html>
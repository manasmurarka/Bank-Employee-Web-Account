<!DOCTYPE html>
<html>
<body>

<?php
  $num= array(23,1,5,69,45,78,2,8,56);
  sort($num);
  
  for($x=0; $x < count($num);$x++)
   { echo $num[$x] ;
     echo "<br>";}
?>

</body>
</html>
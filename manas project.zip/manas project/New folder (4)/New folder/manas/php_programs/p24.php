<!DOCTYPE html>
<html>
<body>

<?php
  $cars= array("Toyota", "Bmw","Audi");
  $arrlength= count($cars);
  
  for($x=0; $x< $arrlength;$x++)
   { echo $cars[$x];
    echo "<br>";}
?>

</body>
</html>
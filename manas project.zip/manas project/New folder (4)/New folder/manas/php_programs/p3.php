<!DOCTYPE html>
<html>
<body>

<?php
 echo str_word_count("Helloe world!");
?>
</body>
</html>
<!DOCTYPE html>
<html>
<body>

<?php
  function familyname($fname, $year)
  { echo "$fname Das Born in $year<br>";}
  
  familyname("Manas", 1997);
  familyname("Malay", 1783);
  familyname("Ashish", 2348);
?>

</body>
</html>
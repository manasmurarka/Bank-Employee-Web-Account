<!DOCTYPE html>
<html>
<body>

<?php
  $num= array("G"=>"789","B"=> "687","I"=>"875");
  echo "G is ".$num['G']." And I is ".$num['I'];
 ?>

</body>
</html>
<!DOCTYPE html>
<html>
<body>

<?php
 define("Greeting", "Welcome to w3schools.com!");
 echo Greeting;
?>

</body>
</html>
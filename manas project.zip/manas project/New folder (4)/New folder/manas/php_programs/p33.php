<!DOCTYPE html>
<html>
<body>

<?php
  $num= array("V"=>"789","B"=> "987","C"=>"875");
  ksort($num);
  
  foreach($num as $x => $x_value)
  { echo " The value for key " .$x." is ".$x_value;
  }
 ?>

</body>
</html>
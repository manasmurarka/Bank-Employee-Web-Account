<!DOCTYPE html>
<html>
<body>

<?php
   echo "The time is ".date("h:i:s a");
?>

</body>
</html>
<!DOCTYPE html>
<html>
<body>

<?php
  $cars[0]="Toyota";
  $cars[1]="Audi";
  $cars[2]="BMW";
  echo "I like ".$cars[0].", ".$cars[1].", ".$cars[2].".";
?>

</body>
</html>
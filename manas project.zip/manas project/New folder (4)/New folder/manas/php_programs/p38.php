<!DOCTYPE html>
<html>
<body>

<?php
   date_default_timezone_set("America/New_York");
   echo "The time is ".date("h:i:s a");
?>

</body>
</html>
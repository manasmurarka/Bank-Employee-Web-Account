<html>

<head>
<title>Divisible by 5</title>
</head>

<body>
<?php
 for($x=1;$x<=50;$x++)
  { if($x%5==0)
      {echo $x." , ";}
  }
?>
</body>

</html>


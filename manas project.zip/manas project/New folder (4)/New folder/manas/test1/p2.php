<html>

<body>
  Welcome<?php echo $_GET["name"]; ?><br>
  E-mail: <?php echo $_GET["email"];?><br>
  Number: <?php echo $_GET["num"];?><br>
</body>

</html>
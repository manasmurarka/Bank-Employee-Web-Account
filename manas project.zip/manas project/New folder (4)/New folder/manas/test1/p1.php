<html>

<body>
  Welcome<?php echo $_POST["name"]; ?><br>
  E-mail: <?php echo $_POST["email"];?><br>
  Number: <?php echo $_POST["num"];?><br>
</body>

</html>
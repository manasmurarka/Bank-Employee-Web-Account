<html>

<head>
<title>Calculator</title>
</head>

<body>
<?php
   $x=$_POST["num1"];
   $y=$_POST["num2"];
   $a=$_POST["operator"];
   $b=$_POST["sub"]; 
   $z=0;
 if($b=="Submit")
 {

   if($a=="+")
      $z=$x+$y;
   if($a=="-")
      $z=$x-$y;
   if($a=="*")
      $z=$x*$y;
   if($a=="/")
      $z=$x/$y;
 }


?>

<form action="calc.php" method="post">
 <input type="text" name="num1" value="<?php echo $x;?>">
 <select name="operator">
  <option value="+"> +
  <option value="-"> -
  <option value="*"> *
  <option value="/"> /
 </select>
 <input type="text" name="num2" value="<?php echo $y;?>"><br><br>
 <input type="submit" name="sub" value="Submit"><br><br>
 Result is:<input type="text" name="result" value="<?php echo $z;?>">
</form>
</body>
</html>